// mbid.js - route module for MusicBrainzID, version 1.1.0
const NR_ALBUMS = 15;
const CACHE_TIMEOUT = 7;
const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const NodeCache = require('node-cache');
const cache = new NodeCache({ stdTTL: CACHE_TIMEOUT, checkperiod: 0 });

router.get('/', function (req, res) {
  res.send('Hello from "/mbid".');
});

router.get('/:artist', (req, res) => {
  const mbid = req.params.artist;
  const cachedResult = cache.get(mbid);
  if (cachedResult) {
    res.send(cachedResult);
  } else {
    setCachedResult(mbid, res);
  }
});

function setCachedResult (mbid, res) {
  const urlMBID = 'https://musicbrainz.org/ws/2/artist/' + mbid +
    '?fmt=json&inc=url-rels+release-groups';
  const promiseMBIDwiki = fetch(urlMBID)
    .then(responseMBID => {
      if (responseMBID.status === 400) {
        res.status(400).send('Error 400 - Bad request - Invalid MBID.' +
          '<br> --> See https://musicbrainz.org/development/mmd');
      } else {
        return responseMBID.json();
      }
    })
    .then(jsonMBID => {
      console.log(' -*-*-\n MBID: ' + mbid + ' = ' + jsonMBID.name);
      const relationsWikidata = jsonMBID.relations.find(obj =>
        obj.type === 'wikidata');
      const wikidataId = relationsWikidata.url.resource.split('/').pop();
      const urlWikidata =
        'https://www.wikidata.org/w/api.php?action=wbgetentities&ids=' +
        wikidataId + '&format=json&props=sitelinks';
      return fetch(urlWikidata)
        .then(responseWikidata => responseWikidata.json())
        .then(jsonWikidata => {
          const wikiArtistName =
            jsonWikidata.entities[wikidataId].sitelinks.enwiki.title.trim();
          const urlWikipedia = 'https://en.wikipedia.org/w/api.php?action=' +
            'query&format=json&prop=extracts&exintro=true&redirects=true' +
            '&titles=' + wikiArtistName;
          return fetch(urlWikipedia)
            .then(responseWikipedia => responseWikipedia.json())
            .then(jsonWikipedia => {
              const queryPages = jsonWikipedia.query.pages;
              const extract =
                queryPages[Object.keys(queryPages)[0]].extract;
              const wikiDescr = extract.slice(1 +
                extract.indexOf('\n<p><b>'), -1) + extract.substr(-1);
              console.log(' wikiDescr: ' + wikiDescr.slice(0, 79) + ' ...\n');
              jsonMBID.wikiDescr = wikiDescr;
              return jsonMBID;
            }).catch(_ =>
              console.error('-- ERROR! Request failed:\n ' + urlWikipedia));
        }).catch(_ =>
          console.error('-- ERROR! Request failed:\n ' + urlWikidata));
    }).catch(_ => console.error('-- ERROR! Request failed:\n ' + urlMBID));
  promiseMBIDwiki.then(jsonMBID => {
    const album2Titles = [];
    const album2IDs = [];
    const albumImageUrls = [];
    const jsonAlbums = jsonMBID['release-groups'];
    for (const item of jsonAlbums) {
      album2Titles.push(item.title);
      album2IDs.push(item.id);
      albumImageUrls.push('https://coverartarchive.org/release-group/' +
          item.id);
    } // The next line determines how many albums to return.
    album2Titles.length = album2IDs.length = albumImageUrls.length =
      NR_ALBUMS;
    return Promise.all(albumImageUrls.map(url => fetch(url)
      .then(responseCover => responseCover.json())
      .then(jsonCover => jsonCover.images.find(obj =>
        obj.front === true).thumbnails.small)))
      .then(imageURLs => {
        const albumTitles = album2Titles.map(value => ({ title: value }));
        const albumIDs = album2IDs.map(value => ({ id: value }));
        const albumsAndIDs = albumTitles.map(
          (item, i) => Object.assign({}, item, albumIDs[i]));
        const albumImages = imageURLs.map(value => ({ image: value }));
        const albumsAndImgs = albumsAndIDs.map(
          (item, i) => Object.assign({}, item, albumImages[i]));
        const result = {
          name: jsonMBID.name,
          mbid: mbid,
          description: jsonMBID.wikiDescr,
          albums: albumsAndImgs
        };
        // // // res.send(result);
        cache.set(mbid, result);
        res.send(result);
      }).catch(err => {
        console.error('Failed to fetch one of the following URLs:');
        console.log(albumImageUrls);
        console.log(err);
      });
  }).catch(_ => console.error('-- ERROR! promiseMBIDwiki failed.'));
}

module.exports = router;
