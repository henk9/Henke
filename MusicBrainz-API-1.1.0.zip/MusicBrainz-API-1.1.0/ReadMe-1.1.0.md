# MusicBrainz mashup API – hemuppgift
Version 1.1.0

## Om min lösning
Jag har valt att bygga mitt API i JavaScript/Node.js med Express som
 ramverk.
Huvud-modulen är `appMBID.js` och den startas med kommandot
 `npm run start` från ett terminal-fönster (i Windows: `cmd.exe`).
Det mesta av koden finns dock i `routes/mbid.js`.

För att utvärdera mitt API, använder jag
[Postman](https://www.postman.com/downloads/), _desktop_, inte
 Chrome-tillägget (_not_ the Chrome extension).
Jag går nu över till engelska, eftersom jag utgår ifrån att läsaren
 förstår det språket.
Jag beskriver nedan hur man startar min Express webb-server och sedan
 inspekterar mitt API i Postman.

### How to install Node.js

* Open a terminal. (On Windows: `cmd.exe`.)
* Type `npm -v` and hit <kbd>Enter</kbd> to see if **Node.js** is
installed.
* If you get `command not found`, download at [**Node.js**](
https://nodejs.org/en/download/) and install.
 <sup>1</sup>  
(On Ubuntu, `sudo apt install -y nodejs` should install Node.js.)

### How to start the server and run the Postman Collection

Running my Postman Collection on the server should be straightforward.  
Assuming you are using [the desktop version of Postman](
https://www.postman.com/downloads/), do as follows:

1. `npm run start` from a command-line window (`cmd.exe` in Windows).  
This should start the server.

[![How to start the Express server and my API][1]][1]

[1]: https://i.imgur.com/HXNKOzS.png
"How to start the Express server and my API"

2. Check that the file `MBID-Display-Albums.pm_coll.json` is in the
 root of this folder (the same location as this `ReadMe` file.)

3. In Postman, _<kbd>Ctrl</kbd> + <kbd>O</kbd> > Upload Files >
 `MBID-Display-Albums.pm_coll.json` > Import_.  
You should now see `MBID-Display-Albums` as a collection in Postman.

4. _(Collections >) `MBID-Display-Albums` > `DummyRequest` > **Send**_.
 <sup>2</sup>

---

<sup>1</sup> I am on Windows 10, and I download and use the 64-bit
 Windows Installer (`.msi`) of Node.js.  
<sup>2</sup> If you get an error –
 _Something went wrong while running your scripts_ –
 try hitting **Send** again.

---

[![Response in Postman using MBID of Kate Bush][2]][2]

[2]: https://i.imgur.com/4ModtvN.png
"Response in Postman using MBID of Kate Bush"

The JSON response in Postman, truncated:

    {
      "name": "Kate Bush",
      "mbid": "4b585938-f271-45e2-b19a-91c634b5e396",
      "description": "<p><b>Catherine Bush</b>  (born 30 July 1958) ...",
      "albums": [
        {
          "title": "The Kick Inside",
          "id": "e8f3a858-20f8-3798-80ac-65264afa4672",
          "image": "http://coverartarchive.org/release/cdf743d9-65fd-3c02-8dac-fef0bb80d0b8/14335136137-250.jpg"
        }, ...
      }
     ]
    }

5. The server "responds" in the command line window as well.

[![The CLI confirms a request on Kate Bush][3]][3]

[3]: https://i.imgur.com/uhBMMSx.png
"The CLI confirms a request on Kate Bush"

6. In the Postman Response Body, click _Visualize_.

[![The front covers of albums by Kate Bush][4]][4]

[4]: https://i.imgur.com/iVAaQX2.png
"The front covers of albums by Kate Bush"

7. You should now be able to scroll 15 albums as indicated by the
 screenshot above.

8. Similar screenshot but for Nirvana,  
MBID = `5b11f4ce-a62d-471e-81fc-a69a8278c7da`.

[![The front covers of albums by Nirvana][5]][5]

[5]: https://i.imgur.com/7Rj4Nrd.png
"The front covers of albums by Nirvana"

### Some more MBIDs to try
* `0383dadf-2a4e-4d10-a46a-e9e041da8eb3` Queen
* `83d91898-7763-47d7-b03b-b92132375c47` Pink Floyd
* `cc197bad-dc9c-440d-a5b5-d52ba2e14234` Coldplay
* `b071f9fa-14b0-4217-8e97-eb41da73f598` The Rolling Stones
* `a74b1b7f-71a5-4011-9441-d0b5e4122711` Radiohead
* `f181961b-20f7-459e-89de-920ef03c7ed0` The Strokes
* `af37c51c-0790-4a29-b995-456f98a6b8c9` Vampire Weekend
* `1a1cd7f3-e5df-4eca-bae2-2757c9e656b5` Duran Duran

<div style="page-break-after: always;"></div>

### The code in `routes/mbid.js`

    // mbid.js - route module for MusicBrainzID, version 1.1.0
    const NR_ALBUMS = 15;
    const CACHE_TIMEOUT = 7;
    const express = require('express');
    const router = express.Router();
    const fetch = require('node-fetch');
    const NodeCache = require('node-cache');
    const cache = new NodeCache({ stdTTL: CACHE_TIMEOUT, checkperiod: 0 });

    router.get('/', function (req, res) {
      res.send('Hello from "/mbid".');
    });

    router.get('/:artist', (req, res) => {
      const mbid = req.params.artist;
      const cachedResult = cache.get(mbid);
      if (cachedResult) {
        res.send(cachedResult);
      } else {
        setCachedResult(mbid, res);
      }
    });

    function setCachedResult (mbid, res) {
      const urlMBID = 'https://musicbrainz.org/ws/2/artist/' + mbid +
        '?fmt=json&inc=url-rels+release-groups';
      const promiseMBIDwiki = fetch(urlMBID)
        .then(responseMBID => {
          if (responseMBID.status === 400) {
            res.status(400).send('Error 400 - Bad request - Invalid MBID.' +
              '<br> --> See https://musicbrainz.org/development/mmd');
          } else {
            return responseMBID.json();
          }
        })
        .then(jsonMBID => {
          console.log(' -*-*-\n MBID: ' + mbid + ' = ' + jsonMBID.name);
          const relationsWikidata = jsonMBID.relations.find(obj =>
            obj.type === 'wikidata');
          const wikidataId = relationsWikidata.url.resource.split('/').pop();
          const urlWikidata =
            'https://www.wikidata.org/w/api.php?action=wbgetentities&ids=' +
            wikidataId + '&format=json&props=sitelinks';
          return fetch(urlWikidata)
            .then(responseWikidata => responseWikidata.json())
            .then(jsonWikidata => {
              const wikiArtistName =
                jsonWikidata.entities[wikidataId].sitelinks.enwiki.title.trim();
              const urlWikipedia = 'https://en.wikipedia.org/w/api.php?action=' +
                'query&format=json&prop=extracts&exintro=true&redirects=true' +
                '&titles=' + wikiArtistName;
              return fetch(urlWikipedia)
                .then(responseWikipedia => responseWikipedia.json())
                .then(jsonWikipedia => {
                  const queryPages = jsonWikipedia.query.pages;
                  const extract =
                    queryPages[Object.keys(queryPages)[0]].extract;
                  const wikiDescr = extract.slice(1 +
                    extract.indexOf('\n<p><b>'), -1) + extract.substr(-1);
                  console.log(' wikiDescr: ' + wikiDescr.slice(0, 79) + ' ...\n');
                  jsonMBID.wikiDescr = wikiDescr;
                  return jsonMBID;
                }).catch(_ =>
                  console.error('-- ERROR! Request failed:\n ' + urlWikipedia));
            }).catch(_ =>
              console.error('-- ERROR! Request failed:\n ' + urlWikidata));
        }).catch(_ => console.error('-- ERROR! Request failed:\n ' + urlMBID));
      promiseMBIDwiki.then(jsonMBID => {
        const album2Titles = [];
        const album2IDs = [];
        const albumImageUrls = [];
        const jsonAlbums = jsonMBID['release-groups'];
        for (const item of jsonAlbums) {
          album2Titles.push(item.title);
          album2IDs.push(item.id);
          albumImageUrls.push('https://coverartarchive.org/release-group/' +
              item.id);
        } // The next line determines how many albums to return.
        album2Titles.length = album2IDs.length = albumImageUrls.length =
          NR_ALBUMS;
        return Promise.all(albumImageUrls.map(url => fetch(url)
          .then(responseCover => responseCover.json())
          .then(jsonCover => jsonCover.images.find(obj =>
            obj.front === true).thumbnails.small)))
          .then(imageURLs => {
            const albumTitles = album2Titles.map(value => ({ title: value }));
            const albumIDs = album2IDs.map(value => ({ id: value }));
            const albumsAndIDs = albumTitles.map(
              (item, i) => Object.assign({}, item, albumIDs[i]));
            const albumImages = imageURLs.map(value => ({ image: value }));
            const albumsAndImgs = albumsAndIDs.map(
              (item, i) => Object.assign({}, item, albumImages[i]));
            const result = {
              name: jsonMBID.name,
              mbid: mbid,
              description: jsonMBID.wikiDescr,
              albums: albumsAndImgs
            };
            // // // res.send(result);
            cache.set(mbid, result);
            res.send(result);
          }).catch(err => {
            console.error('Failed to fetch one of the following URLs:');
            console.log(albumImageUrls);
            console.log(err);
          });
      }).catch(_ => console.error('-- ERROR! promiseMBIDwiki failed.'));
    }

    module.exports = router;

---

## Bakgrund
Uppgiften går ut på att skapa ett REST API som är uppbyggt av
 bakomliggande API:er.  
De API:er som ska kombineras
 är _​MusicBrainz​_, _​Wikidata​_/_​Wikipedia​_ och _Cover Art Archive​_.

* MusicBrainz erbjuder ett API med information om
musikartister/musikband.

* Wikipedia innehåller beskrivande information om bland annat just
 musikartister.
För att korrekt länka en artist eller ett band till rätt sida hos
 Wikipedia behöver länkningen göras via Wikidata.

* Cover Art Archive hör till MusicBrainz och länkar bland annat till
bilder på albumens omslag.

Mitt API tar emot ett ​MBID (MusicBrainz IDentifier)​ och levererar
 tillbaka ett resultat bestående av:
* en beskrivning av artisten som hämtas från Wikipedia,
* en lista över alla album som artisten släppt och länkar till bilder
 för varje album.  
Listan över album hämtas från MusicBrainz men bilderna hämtas från
 Cover Art Archive.

<div style="page-break-after: always;"></div>

## Externa API:er

### MusicBrainz
* Dokumentation:
[http://musicbrainz.org/doc/Development/XML_Web_Service/Version_2](
http://musicbrainz.org/doc/Development/XML_Web_Service/Version_2)
* Exempelfråga:
[http://musicbrainz.org/ws/2/artist/5b11f4ce-a62d-471e-81fc-a69a8278c7da?&fmt=json&inc=url-rels+release-groups](
http://musicbrainz.org/ws/2/artist/5b11f4ce-a62d-471e-81fc-a69a8278c7da?&fmt=json&inc=url-rels+release-groups)

### Wikidata
* Dokumentation:
[​https://www.wikidata.org/w/api.php](
​https://www.wikidata.org/w/api.php)
* Exempelfråga:
[https://www.wikidata.org/w/api.php?action=wbgetentities&ids=Q11649&format=json&props=sitelinks](
https://www.wikidata.org/w/api.php?action=wbgetentities&ids=Q11649&format=json&props=sitelinks)

### Wikipedia
* Dokumentation: [https://www.mediawiki.org/wiki/API:Main_page](
https://www.mediawiki.org/wiki/API:Main_page)
* Exempelfråga:
[https://en.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=true&redirects=true&titles=Nirvana%20(band)](
https://en.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=true&redirects=true&titles=Nirvana%20(band))

### Cover Art Archive
* Dokumentation: [https://wiki.musicbrainz.org/Cover_Art_Archive/API](
https://wiki.musicbrainz.org/Cover_Art_Archive/API)
* Exempelfråga:
[http://coverartarchive.org/release-group/1b022e01-4da6-387b-8658-8678046e4cef](
http://coverartarchive.org/release-group/1b022e01-4da6-387b-8658-8678046e4cef)
 (Nevermind by Nirvana)

---

## Krav
* _API:et ska kunna hantera hög last._

Kommentar: i den här versionen (1.1.0) har jag uppfyllt det här kravet.
Jag har valt en enkel lösning som använder sig av 
[`node-cache`](https://www.npmjs.com/package/node-cache).
Timeout för cachen är med avsikt satt till endast 7 sekunder.
Detta för att det enkelt ska gå att lägga märke skillnaden i snabbhet
 mellan ett cachat respektive icke-cachat anrop.
För körning i produktion ska denna siffra höjas avsevärt – förslagsvis
 till åtminstone 600 (tio minuter), eller rentav till 3600 (en timme).

Följande tre krav är uppfyllda:
* _API:et ska vara av typen ​REST._
* _Format i överföring och svar: ​JSON​._
* _Svaret från tjänsten ska innehålla en beskrivning och ett antal
 album i enlighet med **The JSON response in Postman, truncated**
 ovan._

### Utvecklingsmiljö – JavaScript/Node.js
* En Node.js-lösning ska gå att starta via `yarn run start` eller
 `npm run start`.
* Rekommenderade ramverk: Hapi​, Koa​ eller ​Express.