const express = require('express');
const app = express();
const port = 3000;
const mbid = require('./routes/mbid.js');

app.get('/', (req, res) => {
  res.send('Hello from "appMBID.js".');
  console.log('http://127.0.0.1:3000/ refreshed!.');
});

app.use('/mbid', mbid);

app.listen(port, () => {
  console.log(` "appMBID.js" listening on port ${port}.`);
});
