// ``` React Native code
import React from 'react';
import { Image, ScrollView, StyleSheet, Text, View } from 'react-native';

const logoImage = { uri: 'https://i.stack.imgur.com/15jTl.png' };

export default function LoadingScreen() {
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollView}>
        <Image style={styles.logo} source={logoImage} />
        <Text>Here are some</Text>
        <Text>lines of text</Text>
        <Text>below the image.</Text>
        <Text> - - -</Text>
        <Text>I want the image</Text>
        <Text>to be centered,</Text>
        <Text>but this text</Text>
        <Text>to be left-aligned,</Text>
        <Text>not centered.</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 8 },
  scrollView: { flexGrow: 1, justifyContent: 'center' },
  logo: { alignSelf: 'center', width: 280, height: 260 },
});
// ```
