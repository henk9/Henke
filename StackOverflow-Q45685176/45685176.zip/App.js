import React from 'react';
import LoadingScreen from './screens/LoadingScreen';

export default function App() {
  return <LoadingScreen />;
}
